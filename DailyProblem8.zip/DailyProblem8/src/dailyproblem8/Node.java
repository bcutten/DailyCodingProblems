/*
 * B Cutten
 * April 12, 2019
 * A Node class which has a value and two children (left, right)
 */
package dailyproblem8;

public class Node {

    private int value;
    private Node left;
    private Node right;

    /**
     * Construct a node with a given value and no children
     * @param value - the int for the node to hold
     */
    public Node(int value) {
        this.value = value;
        left = null;
        right = null;
    }

    /**
     * Getter for the node's value
     * @return the int the Node holds
     */
    public int getValue() {
        return value;
    }

    /**
     * Setter for the node's value
     * @param value the new int for the node to hold
     */
    public void setValue(int value) {
        this.value = value;
    }

    /**
     * Getter for the Node's left child
     * @return the left child node
     */   
    public Node getLeft() {
        return left;
    }

    /**
     * Setter for the node's left child
     * @param left the new left child node
     */
    public void setLeft(Node left) {
        this.left = left;
    }

    /**
     * Getter for the node's right child
     * @return the right child's node
     */
    public Node getRight() {
        return right;
    }

    /**
     * Setter for the node's right child
     * @param right the new right child 
     */
    public void setRight(Node right) {
        this.right = right;
    }

    @Override
    public String toString() {
        return "Node{" + "value=" + value + ", \n\tleft=\t" + left + ", \n\tright=\t" + right + '}';
    }
    
    
}
