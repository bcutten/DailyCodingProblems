/*
 * B Cutten
 * April 13, 2019
 * An int binary tree data structure, with help from:
 * https://www.geeksforgeeks.org/tree-traversals-inorder-preorder-and-postorder/
 */
package dailyproblem8;

public class BinaryTree {
    private Node root;
    
    /**
     * A new empty tree
     */
    public BinaryTree(){
        root = null;
    }
    
    /**
     * A tree with one root node
     * @param value - the integer to store in the root
     */
    public BinaryTree(int value){
        root = new Node(value);
    }
    
    /**
     * Getter for the root of the tree
     * @return - a reference to the root 
     */
    public Node getRoot() {
        return root;
    }

    /**
     * A setter for the root of the tree
     * @param root - the new root
     */
    public void setRoot(Node root) {
        this.root = root;
    }

    /**
     * A method which counts the number of unival trees within this tree
     * @param root - the starting place
     * @return the number of unival subtrees trees
     */
    public int countUnivals(Node root){      
        if(root == null){ //base case, an empty tree is not unival
            return 0;
        }else if (isUnival(root)){ //if this tree is unival, count it then count it's two children
            return 1 + countUnivals(root.getLeft()) + countUnivals(root.getRight());
        }else{ //this tree is not unival so just count the children
            return countUnivals(root.getLeft()) + countUnivals(root.getRight());
        }
    }
    
    /**
     * A method to check if a tree is unival or not
     * @param root - the root of the tree to check
     * @return - true if the tree is unival, false if it's not
     */
    public boolean isUnival(Node root){
        //base case #1, if theres no root, or the root is a leaf, then the tree is uni value
        if(root == null || (root.getLeft() == null && root.getRight() == null)){
            return true;
        }else if(root.getLeft() != null && root.getRight() != null 
                && root.getLeft().getValue() != root.getRight().getValue()){
            //base case #2 if there's a leaf on each branch, and they don't equal each other
            //then its not univalue
            return false;
        }else{
            //if both branches of this tree are unival, then the whole tree is
            return isUnival(root.getLeft()) && isUnival(root.getRight());
        }
    
    }
    
    /**
     * A method which prints this tree in pre-order format
     * @param root - the starting node in the tree
     * @return a pre order String representation of the tree
     */
    public String printPreOrder(Node root){        
        if (root == null){ //base case, the root is null, so return nothing
            return "";
        }else{
            //add the value of the root to the pre order Strings of the left then the right child
            return root.getValue() + "\n" 
                    + printPreOrder(root.getLeft()) + " " + printPreOrder(root.getRight());
        }
    }
    
    /**
     * A method which prints this tree in post-order format
     * @param root - the starting node in the tree
     * @return a post order String representation of the tree
     */
    public String printPostOrder(Node root){        
        if (root == null){ //base case, the root is null, so return nothing
            return "";
        }else{
            //add the post order String of the left child, then the right child, then the value of the root 
            return printPostOrder(root.getLeft()) + " " + printPostOrder(root.getRight())+ " " + root.getValue();
        }
    } 
    
    /**
     * A method which prints this tree in in order format
     * @param root - the starting node in the tree
     * @return an in order String representation of the tree
     */
    public String printInOrder(Node root){
        //base case, the root is null, so return nothing
        if (root == null){
            return "";
        }else{
            //add the in order String of the left child, then the value of the root, then the in order String of the right child,  
            return printInOrder(root.getLeft()) + " " + root.getValue()+ " " + printInOrder(root.getRight());
        }
    }
   
    
}
