/*
 * This problem was asked by Google.

A unival tree (which stands for "universal value") is a tree where all nodes 
under it have the same value.

Given the root to a binary tree, count the number of unival subtrees.

For example, the following tree has 5 unival subtrees:

   0
  / \
 1   0
    / \
   1   0
  / \
 1   1
 */

package dailyproblem8;

/**
 * This is an application which
 * Created 12-Apr-2019 on 9:16:33 AM
 * @author B. Cutten
 */
public class DailyProblem8 {

   
    public static void main(String[] args) {
        //grow the tree
        BinaryTree tree = new BinaryTree(0);
        tree.getRoot().setLeft(new Node(1));
        tree.getRoot().setRight(new Node(0));
        tree.getRoot().getRight().setLeft(new Node(1));
        tree.getRoot().getRight().setRight(new Node(0));
        tree.getRoot().getRight().getLeft().setLeft(new Node(1));
        tree.getRoot().getRight().getLeft().setRight(new Node(1));
        
        //grow a smaller tree for testing
        BinaryTree t2 = new BinaryTree(1);
        t2.getRoot().setLeft(new Node(1));
        t2.getRoot().setRight(new Node(0));
        System.out.println(t2.countUnivals(t2.getRoot()));
        
        //seems to work with the sapling, let's try with the real deal
        System.out.println(tree.countUnivals(tree.getRoot()));
    }
    
    
    
    

}
